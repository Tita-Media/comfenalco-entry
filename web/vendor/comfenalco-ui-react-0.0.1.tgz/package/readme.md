# comfenalco-ui-react

Wrappers React auto-generados para los web components de Comfenalco ([`@stencil/react-output-target`](https://stenciljs.com/docs/react)).

**No editar** `src/components/stencil-generated/` — se regenera al compilar `comfenalco-ui-wc`.

Documentación interactiva (instalación, estilos, uso y catálogo):

```bash
# desde la raíz del monorepo
npm run storybook
```

Abre **http://localhost:6006** → sección **Documentation/**. MDX en `src/docs/`.

## Instalación

```bash
npm install comfenalco-ui-react
```

Peer dependencies: `react`, `react-dom` (^18 o ^19).

## Uso

```tsx
// Entry de la app (obligatorio, una sola vez)
import 'comfenalco-ui-react/styles';

import { CfAlert, CfButton } from 'comfenalco-ui-react';

export function Example() {
  return (
  <>
    <CfAlert variant="success" title="SUCCESS" dismissible onCfClose={() => {}}>
      La operación se completó con éxito.
    </CfAlert>
    <CfButton variant="primary">Continuar</CfButton>
  </>
  );
}
```

## Exports

| Subpath | Contenido |
|---------|-----------|
| `comfenalco-ui-react` | Barrel completo (componentes + tipos + `useToast`) |
| `comfenalco-ui-react/components` | Wrappers Stencil (`src/components/stencil-generated/`) |
| `comfenalco-ui-react/styles` | Estilos globales de `comfenalco-ui-wc` |

## Componentes disponibles

| Export React | Web component |
|------------|---------------|
| `CfAlert` | `cf-alert` |
| `CfBadge` | `cf-badge` |
| `CfBreadcrumbs` | `cf-breadcrumbs` |
| `CfButton` | `cf-button` |
| `CfCard` | `cf-card` |
| `CfCheckbox` | `cf-checkbox` |
| `CfFileUpload` | `cf-file-upload` |
| `CfIcon` | `cf-icon` |
| `CfInput` | `cf-input` |
| `CfKpiMetric` | `cf-kpi-metric` |
| `CfModal`, `CfModalFooter` | `cf-modal`, `cf-modal-footer` |
| `CfPagination` | `cf-pagination` |
| `CfRadio`, `CfRadioGroup` | `cf-radio`, `cf-radio-group` |
| `CfSelect` | `cf-select` |
| `CfSkeleton`, `CfSkeletonCard`, `CfSkeletonGroup`, `CfSkeletonKpiMetric`, `CfSkeletonTable` | `cf-skeleton`, … |
| `CfStatusCard` | `cf-status-card` |
| `CfStepper`, `CfStepperStep` | `cf-stepper`, `cf-stepper-step` |
| `CfTab`, `CfTabs` | `cf-tab`, `cf-tabs` |
| `CfTable` | `cf-table` |
| `CfToast`, `CfToastProvider`, `CfToastTrigger` | `cf-toast`, … |
| `CfTooltip` | `cf-tooltip` |

Utilidades: `useToast`, `showToast`, `dismissToast`, `getToastDurationForVariant`, `TOAST_DEFAULT_DURATION_MS`, `TOAST_PERSISTENT_VARIANTS`.

## Eventos

Eventos Stencil `cf*` → props React `onCf*`. Ejemplo: `onCfChange={(e) => console.log(e.detail)}`.

## Build (desarrollo del monorepo)

```bash
npm run build:react-wc
```
