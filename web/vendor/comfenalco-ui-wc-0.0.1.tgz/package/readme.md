# comfenalco-ui-wc

Web Components del design system Comfenalco, compilados con [Stencil](https://stenciljs.com/docs/introduction).

Fuente de verdad de la UI: los wrappers React en `comfenalco-ui-react` se generan desde este paquete.

Documentación completa de consumo: [README del monorepo](../../README.md).

## Instalación

```bash
npm install comfenalco-ui-wc
```

## Uso rápido

```ts
import 'comfenalco-ui-wc/styles';
import { defineCustomElements } from 'comfenalco-ui-wc/loader';

defineCustomElements();
```

```html
<cf-button variant="primary">Enviar</cf-button>
<cf-input label="Nombre" placeholder="Tu nombre"></cf-input>
```

```js
document.querySelector('cf-input').addEventListener('cfChange', (e) => {
  console.log(e.detail);
});
```

## Exports

| Subpath | Contenido |
|---------|-----------|
| `comfenalco-ui-wc` | Tipos, `showToast`, `dismissToast`, utilidades |
| `comfenalco-ui-wc/loader` | `defineCustomElements()` |
| `comfenalco-ui-wc/styles` | CSS global compilado |
| `comfenalco-ui-wc/dist/components/cf-*.js` | Custom elements individuales |

## Componentes (`cf-*`)

| Tag | Descripción |
|-----|-------------|
| `cf-alert` | Banner de estado inline con cierre opcional |
| `cf-badge` | Etiqueta compacta de estado |
| `cf-breadcrumbs` | Ruta de navegación jerárquica |
| `cf-button` | CTA primary / secondary / tertiary / link |
| `cf-card` | Contenedor con header, body y footer |
| `cf-checkbox` | Casilla de verificación accesible |
| `cf-file-upload` | Selector de archivos con lista |
| `cf-icon` | Material Symbols (también uso interno) |
| `cf-input` | Campo de texto con label, helper y error |
| `cf-kpi-metric` | Tarjeta de métrica con tendencia |
| `cf-modal`, `cf-modal-footer` | Diálogo accesible con acciones |
| `cf-pagination` | Control de paginación |
| `cf-radio`, `cf-radio-group` | Opción única y grupo de radios |
| `cf-select` | Select nativo con estilos de marca |
| `cf-skeleton`, `cf-skeleton-*` | Placeholders de carga |
| `cf-status-card` | Tarjeta success / error / warning |
| `cf-stepper`, `cf-stepper-step` | Indicador de progreso |
| `cf-tab`, `cf-tabs` | Pestañas con panel por tab |
| `cf-table` | Tabla responsive configurable |
| `cf-toast`, `cf-toast-provider`, `cf-toast-trigger` | Notificaciones temporales |
| `cf-tooltip` | Etiqueta contextual al hover/focus |

Props complejos (`columns`, `options`, `items`) aceptan JSON string en HTML o array/objeto desde frameworks.

## Storybook

```bash
# desde la raíz del monorepo
npm run storybook:wc
```

Abre **http://localhost:6007**.

- **Documentation/** — instalación, estilos, uso en frameworks, convenciones y FAQ (MDX en `src/docs/`)
- **Web Components/** — stories interactivas en `src/components/cf-[nombre]/cf-[nombre].stories.ts`

## Desarrollo local

```bash
npm install
npm run dev:wc          # Stencil dev server (http://localhost:3333)
npm run sync:wc-styles  # tras editar src/styles/globals.css en la raíz
```

## Agregar un componente

```bash
cd packages/comfenalco-ui-wc
npm run generate
```

Convenciones: `shadow: false`, sin Tailwind inline, clases `.kit-*` / `.cf-*` en `globals.css`.
